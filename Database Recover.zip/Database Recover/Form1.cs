﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.ServiceProcess;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Management;
using Microsoft.Win32;

namespace Database_Recover
{

    public partial class Form1 : Form
    {
    public Form1()
        {
            InitializeComponent();
              this.StartPosition = FormStartPosition.CenterScreen;

        }


        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void databaseComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
      
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
       
        }

        private void databaseComboBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                if (databaseComboBox.DroppedDown)
                {
                
                    databaseComboBox.SelectedItem = databaseComboBox.Items[0];
                }
                e.SuppressKeyPress = true; 
            }
        }

        private void serverComboBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (serverComboBox.DroppedDown)
                {
                   
                    serverComboBox.SelectedItem = serverComboBox.Items[0];
                }
                e.SuppressKeyPress = true; 
            }
        }

    


        private void button1_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            string selectedServer = serverComboBox.Text.ToString();
            string selectedDatabase = databaseComboBox.Text.ToString();
            string username = usernameTextBox.Text;
            string password = passwordTextBox.Text;




            if (string.IsNullOrWhiteSpace(selectedServer) || string.IsNullOrWhiteSpace(selectedDatabase) || string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                Cursor = Cursors.Default;
                MessageBox.Show("Please fill in all required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            // Construct the connection string
            string connectionString = $"Data Source={selectedServer};User ID={username};Password={password};";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Construct the recovery script based on the selected database
                    string recoveryScript = GetRecoveryScript(selectedDatabase);

                    // Execute the recovery script
                    using (SqlCommand command = new SqlCommand(recoveryScript, connection))
                    {
                  
                    
                        command.ExecuteNonQuery();
                    }
                    Cursor = Cursors.Default;
                    MessageBox.Show($"{selectedDatabase} Database recovery completed successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        // Construct the recovery script based on the selected database
                        string recoveryScript = GetRecoveryScript2(selectedDatabase);

                        // Execute the recovery script
                        using (SqlCommand command = new SqlCommand(recoveryScript, connection))
                        {


                            command.ExecuteNonQuery();
                        }
                        Cursor = Cursors.Default;
                        MessageBox.Show($"{selectedDatabase} Database recovery completed successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    Cursor = Cursors.Default;
                    MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            finally
            {
                Cursor = Cursors.Default;
                password = "";
                passwordTextBox.Text = "";
             
            }

        }
      
        private void Form1_Load(object sender, EventArgs e)
        {
        usernameTextBox.Text="sa";
        passwordTextBox.Text="0000000";

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

     private string GetRecoveryScript2(string databaseName)
        {
            try
            {
                string script = $@"
USE master;
DBCC CHECKDB ({databaseName});
ALTER DATABASE {databaseName} SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
DBCC CHECKDB ({databaseName}, REPAIR_ALLOW_DATA_LOSS);
ALTER DATABASE {databaseName} SET MULTI_USER;
";
                return script;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;

            }
        }

        private string GetRecoveryScript(string databaseName)
        {
            // Construct and return the recovery script here based on the selected database
            try
            {
                string script = $@"
USE master;
ALTER DATABASE {databaseName} SET EMERGENCY;
DBCC CHECKDB ({databaseName});
ALTER DATABASE {databaseName} SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
DBCC CHECKDB ({databaseName}, REPAIR_ALLOW_DATA_LOSS);
ALTER DATABASE {databaseName} SET MULTI_USER;
";
                return script;
            }
        catch (Exception ex)
            {
               
                  MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;


            }
        }

        private void databaseComboBox_TextChanged(object sender, EventArgs e)
        {
            string searchText = databaseComboBox.Text.ToLower();
            List<string> filteredItems = new List<string>();

            foreach (string dbName in databaseComboBox.Items)
            {
                if (dbName.ToLower().Contains(searchText))
                {
                    filteredItems.Add(dbName);
                }
            }

            // Clear the combo box items
            databaseComboBox.Items.Clear();

            // Add the filtered items back to the combo box
            databaseComboBox.Items.AddRange(filteredItems.ToArray());

            // Show the drop-down list if it's not already open
            if (!databaseComboBox.DroppedDown)
            {
                databaseComboBox.DroppedDown = true;
            }

            // Set the text selection position to the end to maintain the user's input
            databaseComboBox.SelectionStart = searchText.Length;
        }


        // ...
       
   
    private void serverComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        private void button2_Click(object sender, EventArgs e)
        {

            Cursor = Cursors.WaitCursor;
            string selectedServer = serverComboBox.Text.ToString();
            string username = usernameTextBox.Text;
            string password = passwordTextBox.Text;

            if (!string.IsNullOrEmpty(selectedServer))
            {

                if (string.IsNullOrWhiteSpace(selectedServer) || string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
                {
                    Cursor = Cursors.Default;
                    MessageBox.Show("Please fill in all required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }


                // Construct the connection string
                string connectionString = $"Data Source={selectedServer};User ID={username};Password={password};";
                //// Construct the connection string for the selected server
                //string connectionString = $"Data Source={selectedServer};Integrated Security=True;";

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        // Query to get the list of databases on the selected server
                        string query = "SELECT name FROM sys.databases";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                databaseComboBox.Items.Clear(); // Clear existing items
                                while (reader.Read())
                                {
                                    string dbName = reader.GetString(0);
                                    databaseComboBox.Items.Add(dbName);
                                }
                                Cursor = Cursors.Default;
                                if (databaseComboBox.Items.Count >= 1)
                                {
                                    databaseComboBox.SelectedIndex = 0;

                                }
                                MessageBox.Show("Database added in combo box", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Cursor = Cursors.Default;
                    MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                Cursor = Cursors.Default;
                MessageBox.Show("Please fill in all required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            string serviceName = "SQLBrowser"; // The service name may vary depending on your SQL Server version
            string startMode = "Automatic"; // Change to "Manual" if desired

            try
            {
                    ManagementPath path = new ManagementPath($"Win32_Service.Name='{serviceName}'");
                    ManagementObject service = new ManagementObject(path);
                    string currentStartMode = service.GetPropertyValue("StartMode").ToString();

                    if (currentStartMode.Equals(startMode, StringComparison.OrdinalIgnoreCase))
                    {
                        return; 
                    }
                    else
                    {
                        service.InvokeMethod("ChangeStartMode", new object[] { startMode });
                  
                        service.Put();
                    }
                
                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error setting service start mode: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            try
            {
                ServiceController sqlBrowserService = new ServiceController(serviceName);

                if (sqlBrowserService.Status == ServiceControllerStatus.Stopped)
                {
                    sqlBrowserService.Start();
                    sqlBrowserService.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(30));
                    MessageBox.Show("SQL Server Browser service started successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

               
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error starting SQL Server Browser service: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Cursor = Cursors.WaitCursor;
            try
            {
                DataTable servers = SqlDataSourceEnumerator.Instance.GetDataSources();
                serverComboBox.Items.Clear();
                // Iterate through the DataTable and add server names to the ComboBox
                foreach (DataRow row in servers.Rows)
                {
                    string serverName = row["ServerName"].ToString();
                    string instanceName = row["InstanceName"].ToString();

                    if (string.IsNullOrEmpty(instanceName))
                    {
                        serverComboBox.Items.Add(serverName);
                    }
                    else
                    {
                        serverComboBox.Items.Add(serverName + "\\" + instanceName);
                    }
                }
                Cursor = Cursors.Default;
                if (serverComboBox.Items.Count >= 1)
                {
                    serverComboBox.SelectedIndex = 0; 
                }
                MessageBox.Show("Server added in combo box", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                Cursor = Cursors.Default;
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
           
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void bacKup_Click(object sender, EventArgs e)
        {
            string selectedServer = serverComboBox.Text.Trim();
            string username = usernameTextBox.Text.Trim();
            string password = passwordTextBox.Text.Trim();
            string selectedDatabase = databaseComboBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(selectedServer) || string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(selectedDatabase))
            {
                MessageBox.Show("Please fill in all required fields and select a database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string connectionString = $"Data Source={selectedServer};User ID={username};Password={password};";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Perform the database backup
                    string backupFileName = @"C:\Backup.bak"; // Set the backup file path
                    string backupCommand = $"BACKUP DATABASE [{selectedDatabase}] TO DISK = '{backupFileName}'";

                    using (SqlCommand command = new SqlCommand(backupCommand, connection))
                    {
                        command.ExecuteNonQuery();
                    }

                    MessageBox.Show("Database backup completed successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void resTore_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
            {
                folderBrowserDialog.Description = "Select the folder containing database backup files.";

                if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
                {
                    string selectedFolder = folderBrowserDialog.SelectedPath;
                    string selectedServer = serverComboBox.Text.Trim();
                    string username = usernameTextBox.Text.Trim();
                    string password = passwordTextBox.Text.Trim();

                    if (string.IsNullOrWhiteSpace(selectedServer) || string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
                    {
                        MessageBox.Show("Please fill in all required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Get a list of all .bak files in the selected folder
                    string[] backupFiles = Directory.GetFiles(selectedFolder, "*.bak");

                    if (backupFiles.Length == 0)
                    {
                        MessageBox.Show("No backup files (.bak) found in the selected folder.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Sort the backup files
                    Array.Sort(backupFiles);

                    foreach (string backupFile in backupFiles)
                    {
                        string selectedDatabase = Path.GetFileNameWithoutExtension(backupFile);
                        string connectionString = $"Data Source={selectedServer};User ID={username};Password={password};";

                        try
                        {
                            using (SqlConnection connection = new SqlConnection(connectionString))
                            {
                                connection.Open();

                                // Perform the database restore
                                string restoreCommand = $"RESTORE DATABASE [{selectedDatabase}] FROM DISK = '{backupFile}' WITH RECOVERY";

                                using (SqlCommand command = new SqlCommand(restoreCommand, connection))
                                {
                                    command.ExecuteNonQuery();
                                }

                                MessageBox.Show($"Database '{selectedDatabase}' restore completed successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error restoring '{selectedDatabase}': {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }
    }
}
